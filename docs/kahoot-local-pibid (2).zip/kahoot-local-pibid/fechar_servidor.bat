@echo off
chcp 65001 > nul
title Fechar Servidor - EduQuiz Local

echo ======================================================
echo    ENCERRANDO SERVIDOR DO EDUQUIZ LOCAL (PORTA 3000)
echo ======================================================
echo.

for /f "tokens=5" %%a in ('netstat -aon ^| findstr :3000 ^| findstr LISTENING') do (
    echo Encerrando processo PID: %%a...
    taskkill /F /PID %%a >nul 2>&1
)

echo.
echo ======================================================
echo    ✅ A PORTA 3000 FOI FECHADA COM SUCESSO!
echo ======================================================
echo.
pause
