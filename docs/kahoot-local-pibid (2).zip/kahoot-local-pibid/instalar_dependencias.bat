@echo off
chcp 65001 > nul
title Instalador de Dependencias - EduQuiz Local

echo ======================================================
echo    INSTALANDO DEPENDENCIAS DO EDUQUIZ LOCAL
echo ======================================================
echo.
call npm install
echo.
echo ======================================================
echo    CONCLUIDO COM SUCESSO!
echo    Agora basta abrir o arquivo: iniciar_eduquiz.bat
echo ======================================================
pause
