const { io } = require('socket.io-client');

const SERVER_URL = 'http://localhost:3000';

async function runTest() {
  console.log('🧪 Iniciando teste automatizado do EduQuiz Local...');

  const hostSocket = io(SERVER_URL);

  hostSocket.on('connect', () => {
    console.log('✓ Host conectado ao servidor');
    hostSocket.emit('host_create_game', { quizId: 'dia_da_matematica' });
  });

  hostSocket.on('game_created', ({ pin, quizTitle, totalQuestions }) => {
    console.log(`✓ Jogo criado com sucesso! PIN: ${pin} | Quiz: "${quizTitle}" (${totalQuestions} questões)`);
    
    // Conectar dois alunos simulados
    simulatePlayers(pin);
  });

  function simulatePlayers(pin) {
    const p1 = io(SERVER_URL);
    const p2 = io(SERVER_URL);

    p1.on('connect', () => {
      p1.emit('player_join', { pin, nickname: 'Lucas PIBID' });
    });

    p2.on('connect', () => {
      p2.emit('player_join', { pin, nickname: 'Mariana Aluna' });
    });

    let joinedCount = 0;
    hostSocket.on('player_list_update', ({ count, players }) => {
      console.log(`✓ Jogadores no Lobby: ${count} (${players.map(p => p.nickname).join(', ')})`);
      if (count === 2 && joinedCount < 1) {
        joinedCount++;
        console.log('✓ Todos os jogadores entraram. Iniciando jogo...');
        setTimeout(() => {
          hostSocket.emit('host_start_game');
        }, 500);
      }
    });

    hostSocket.on('question_intro', ({ questionNumber, questionText }) => {
      console.log(`✓ Intro da Pergunta ${questionNumber}: "${questionText}"`);
    });

    hostSocket.on('question_active_host', ({ questionNumber, options }) => {
      console.log(`✓ Pergunta ${questionNumber} ativa no Host com ${options.length} alternativas`);
      
      // Aluno 1 responde opção 0 (correta) rapidamente
      setTimeout(() => {
        p1.emit('player_submit_answer', { optionIndex: 0 });
        console.log('  -> Lucas enviou resposta A');
      }, 100);

      // Aluno 2 responde opção 1 após 300ms
      setTimeout(() => {
        p2.emit('player_submit_answer', { optionIndex: 1 });
        console.log('  -> Mariana enviou resposta B');
      }, 400);
    });

    hostSocket.on('question_reveal_host', ({ correctIndex, counts }) => {
      console.log(`✓ Revelação da resposta! Índice correto: ${correctIndex}. Votos: [${counts.join(', ')}]`);
      
      setTimeout(() => {
        hostSocket.emit('host_next_step'); // Ir para o placar
      }, 500);
    });

    hostSocket.on('leaderboard_host', ({ leaderboard }) => {
      console.log('✓ Placar exibido no Host:');
      leaderboard.forEach(p => console.log(`   #${p.rank} ${p.nickname}: ${p.score} pts`));
      
      console.log('\n🎉 TESTE COMPLETO E BEM-SUCEDIDO! O sistema está funcionando perfeitamente.');
      process.exit(0);
    });
  }
}

runTest();
