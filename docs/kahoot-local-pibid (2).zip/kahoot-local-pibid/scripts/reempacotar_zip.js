const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const rootDir = 'C:\\Users\\Axl O S\\OneDrive\\Área de Trabalho\\Backup2\\Mathematics\\PIBID-Aula_Tecnologia\\Kahoot-Clon';
const siteDocs = path.join(rootDir, 'site-kahoot-clone', 'docs');
const sourceDir = path.join(rootDir, 'kahoot-local-pibid');
const zipDest1 = path.join(siteDocs, 'eduquiz-local.zip');
const zipDest2 = path.join(rootDir, 'eduquiz-local.zip');

if (fs.existsSync(zipDest1)) fs.unlinkSync(zipDest1);
if (fs.existsSync(zipDest2)) fs.unlinkSync(zipDest2);

console.log('Criando novo pacote eduquiz-local.zip com EduQuiz.exe...');
const psCmd = `powershell -NoProfile -Command "Get-ChildItem -Path '${sourceDir}' -Exclude node_modules,src_launcher | Compress-Archive -DestinationPath '${zipDest1}' -Force"`;
execSync(psCmd, { stdio: 'inherit' });
fs.copyFileSync(zipDest1, zipDest2);
console.log('[OK] Pacote ZIP atualizado com EduQuiz.exe em:', zipDest1);
