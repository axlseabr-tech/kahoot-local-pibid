import os
import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import parse_xml, OxmlElement
from docx.oxml.ns import nsdecls, qn

def set_cell_background(cell, fill_hex):
    tcPr = cell._element.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    tcPr.append(shd)

def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    tcPr = cell._element.get_or_add_tcPr()
    tcMar = parse_xml(f'''
        <w:tcMar {nsdecls("w")}>
            <w:top w:w="{top}" w:type="dxa"/>
            <w:bottom w:w="{bottom}" w:type="dxa"/>
            <w:left w:w="{left}" w:type="dxa"/>
            <w:right w:w="{right}" w:type="dxa"/>
        </w:tcMar>
    ''')
    tcPr.append(tcMar)

def create_guia_docx():
    doc = docx.Document()

    # Page Margins (2.0 cm)
    for section in doc.sections:
        section.top_margin = Inches(0.8)
        section.bottom_margin = Inches(0.8)
        section.left_margin = Inches(0.8)
        section.right_margin = Inches(0.8)

    # Styles
    style_normal = doc.styles['Normal']
    style_normal.font.name = 'Calibri'
    style_normal.font.size = Pt(11)
    style_normal.font.color.rgb = RGBColor(0x2D, 0x37, 0x48) # #2d3748

    # --- Header Box (Institutional Banner) ---
    header_table = doc.add_table(rows=1, cols=1)
    header_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    header_table.autofit = False
    header_table.columns[0].width = Inches(6.9)

    cell = header_table.rows[0].cells[0]
    set_cell_background(cell, "1A0B2E")
    set_cell_margins(cell, top=180, bottom=180, left=200, right=200)

    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run_inst = p.add_run("UNIVERSIDADE FEDERAL DE RORAIMA — UFRR\nCENTRO DE CIÊNCIAS E TECNOLOGIA • PIBID MATEMÁTICA\n")
    run_inst.font.name = 'Calibri'
    run_inst.font.size = Pt(9.5)
    run_inst.font.bold = True
    run_inst.font.color.rgb = RGBColor(0x00, 0xD2, 0xFF)

    run_title = p.add_run("GUIA OFICIAL DE PUBLICAÇÃO NA MICROSOFT STORE\n")
    run_title.font.name = 'Calibri'
    run_title.font.size = Pt(15)
    run_title.font.bold = True
    run_title.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)

    run_sub = p.add_run("Passo a Passo para Submissão do EduQuiz Local no Microsoft Partner Center")
    run_sub.font.name = 'Calibri'
    run_sub.font.size = Pt(11)
    run_sub.font.color.rgb = RGBColor(0xCE, 0xD6, 0xE0)

    doc.add_paragraph().paragraph_format.space_after = Pt(6)

    # --- Author & Meta Box ---
    meta_table = doc.add_table(rows=1, cols=3)
    meta_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    meta_table.columns[0].width = Inches(2.3)
    meta_table.columns[1].width = Inches(2.3)
    meta_table.columns[2].width = Inches(2.3)

    fields = [
        ("AUTOR / DESENVOLVEDOR", "Axl Oliveira Seabra\nPIBID Matemática • UFRR"),
        ("PROJETO", "EduQuiz Local v1.0\nMicrosoft PWA / MSIX"),
        ("STATUS", "Pronto para Envio\n05/09/2026")
    ]

    for i, (label, val) in enumerate(fields):
        c = meta_table.rows[0].cells[i]
        set_cell_background(c, "F7FAFC")
        set_cell_margins(c, top=80, bottom=80, left=100, right=100)
        p = c.paragraphs[0]
        r_lbl = p.add_run(label + "\n")
        r_lbl.font.size = Pt(8.5)
        r_lbl.font.bold = True
        r_lbl.font.color.rgb = RGBColor(0x71, 0x80, 0x96)
        r_val = p.add_run(val)
        r_val.font.size = Pt(9.5)
        r_val.font.bold = True
        r_val.font.color.rgb = RGBColor(0x2D, 0x37, 0x48)

    doc.add_paragraph().paragraph_format.space_after = Pt(12)

    # Helper function for Headings
    def add_heading_1(text):
        h = doc.add_paragraph()
        h.paragraph_format.space_before = Pt(14)
        h.paragraph_format.space_after = Pt(4)
        h.paragraph_format.keep_with_next = True
        r = h.add_run(text)
        r.font.name = 'Calibri'
        r.font.size = Pt(13)
        r.font.bold = True
        r.font.color.rgb = RGBColor(0x2B, 0x6C, 0xB0) # #2b6cb0
        return h

    def add_heading_2(text):
        h = doc.add_paragraph()
        h.paragraph_format.space_before = Pt(10)
        h.paragraph_format.space_after = Pt(3)
        h.paragraph_format.keep_with_next = True
        r = h.add_run(text)
        r.font.name = 'Calibri'
        r.font.size = Pt(11.5)
        r.font.bold = True
        r.font.color.rgb = RGBColor(0x2D, 0x37, 0x48)
        return h

    def add_bullet(p_or_text, bold_prefix="", text=""):
        if isinstance(p_or_text, str):
            p = doc.add_paragraph(style='List Bullet')
            p.paragraph_format.space_after = Pt(3)
            if bold_prefix:
                r_b = p.add_run(bold_prefix)
                r_b.bold = True
                r_b.font.color.rgb = RGBColor(0x1A, 0x20, 0x2C)
            r_t = p.add_run(text)
            r_t.font.color.rgb = RGBColor(0x4A, 0x55, 0x68)
            return p

    # --- 1. Introdução ---
    add_heading_1("1. Visão Geral: Por que Publicar na Microsoft Store?")
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = 1.15
    p.paragraph_format.space_after = Pt(6)
    p.add_run(
        "A publicação do EduQuiz Local na Microsoft Store é a solução definitiva e mais profissional para disponibilizar o software "
        "a milhares de professores e escolas públicas em todo o Brasil. Ao instalar diretamente pela loja oficial do Windows 10 e Windows 11:"
    )

    add_bullet("", "Zero Avisos de Segurança: ", "O aplicativo recebe a assinatura digital e o selo de confiança da Microsoft, eliminando 100% dos bloqueios do Smart App Control e do Windows Defender.")
    add_bullet("", "Instalação com 1 Clique: ", "Professores e estudantes não precisam abrir terminal, configurar Node.js ou rodar scripts manuais; basta clicar em 'Obter na Store'.")
    add_bullet("", "Atualizações Automáticas e Silenciosas: ", "Sempre que uma nova versão do quiz ou novas funcionalidades forem lançadas, o Windows atualiza o aplicativo em segundo plano.")
    add_bullet("", "Visibilidade Acadêmica e Institucional: ", "O projeto ganha projeção oficial associada à UFRR e ao PIBID Matemática no catálogo global da Microsoft.")

    # --- 2. Etapas de Publicação ---
    add_heading_1("2. Passo a Passo Detalhado da Submissão")

    add_heading_2("Passo 1: Criar sua Conta de Desenvolvedor no Microsoft Partner Center")
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = 1.15
    p.paragraph_format.space_after = Pt(4)
    p.add_run("1. Acesse o portal oficial: ")
    r_link = p.add_run("https://partner.microsoft.com/dashboard/registration")
    r_link.bold = True
    r_link.font.color.rgb = RGBColor(0x00, 0x66, 0xCC)
    p.add_run(" e faça login com sua conta Microsoft (Outlook / Hotmail / Gmail associado).")
    
    add_bullet("", "Tipo de Conta: ", "Selecione a opção 'Individual'.")
    add_bullet("", "Taxa Única: ", "A Microsoft cobra uma taxa única de registro de aproximadamente $19 USD (cerca de R$ 95 a R$ 110, válida para sempre, sem mensalidades ou anuidades).")
    add_bullet("", "Identificação do Editor: ", "Após a aprovação (imediata ou em até 24h), você receberá seu Publisher ID (ex: CN=A1B2C3D4-E5F6-...) no painel de configurações.")

    add_heading_2("Passo 2: Reservar o Nome do Aplicativo no Painel")
    add_bullet("", "No painel do Partner Center: ", "Clique no botão 'Create a new app' (Criar novo aplicativo).")
    add_bullet("", "Nome da Reserva: ", "Digite 'EduQuiz Local - PIBID Matemática UFRR' (ou 'EduQuiz Local') e clique em 'Reserve product name'.")

    add_heading_2("Passo 3: Empacotamento via PWABuilder (Método Oficial Microsoft)")
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = 1.15
    p.paragraph_format.space_after = Pt(4)
    p.add_run(
        "A Microsoft disponibiliza a ferramenta gratuita e oficial PWABuilder (criada pelo time do Edge) para empacotar PWAs "
        "diretamente em pacotes .msix prontos para a Store:"
    )
    add_bullet("", "Acesse a ferramenta: ", "https://www.pwabuilder.com")
    add_bullet("", "URL da Aplicação: ", "Insira a URL do seu portal publicado no GitHub Pages (ex: https://axlseabr-tech.github.io/eduquiz-local/) e clique em 'Start'.")
    add_bullet("", "Geração do Pacote Windows: ", "Clique em 'Package for Stores' e selecione 'Windows (Microsoft Store)'.")
    add_bullet("", "Preenchimento dos IDs: ", "Insira o 'Package ID', 'Publisher Display Name' (Axl Oliveira Seabra) e o 'Publisher ID' obtidos no seu Partner Center.")
    add_bullet("", "Download: ", "Clique em 'Generate Package' para baixar o arquivo .zip com o pacote .msix assinado.")

    add_heading_2("Passo 4: Preenchimento das Propriedades e Classificação Etária (IARC)")
    add_bullet("", "Preço e Disponibilidade: ", "Defina o Preço como 'Gratuito' (Free) e selecione todos os países/mercados (com destaque para o Brasil).")
    add_bullet("", "Categoria da Loja: ", "Education & Reference (Educação e Referência) > Instructional Tools.")
    add_bullet("", "Questionário IARC: ", "Responda às perguntas simples do questionário de classificação (o app não contém violência, sangue, linguagem imprópria ou compras internas). A classificação resultante será 'Livre para todas as idades' (L / All Ages).")
    add_bullet("", "Política de Privacidade: ", "Insira a URL oficial gerada no seu portal: https://axlseabr-tech.github.io/eduquiz-local/politica-privacidade.html")

    # --- 3. Textos da Ficha da Loja ---
    add_heading_1("3. Textos Prontos para a Ficha da Loja (Store Listing)")
    p = doc.add_paragraph()
    p.add_run("Copie e cole os textos abaixo diretamente nos campos correspondentes do Microsoft Partner Center:")

    # Box with store text
    store_table = doc.add_table(rows=1, cols=1)
    store_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    store_table.columns[0].width = Inches(6.9)
    c_st = store_table.rows[0].cells[0]
    set_cell_background(c_st, "F8FAFC")
    set_cell_margins(c_st, top=120, bottom=120, left=150, right=150)

    p_st = c_st.paragraphs[0]
    p_st.paragraph_format.line_spacing = 1.15
    
    r = p_st.add_run("📌 TÍTULO DO PRODUTO:\n")
    r.bold = True
    p_st.add_run("EduQuiz Local - Quiz Gamificado Offline para Escolas\n\n")

    r = p_st.add_run("📌 DESCRIÇÃO CURTA (Até 100 caracteres):\n")
    r.bold = True
    p_st.add_run("Quiz gamificado 100% offline para salas de aula sem internet. Latência zero e conexão por QR Code.\n\n")

    r = p_st.add_run("📌 DESCRIÇÃO COMPLETA:\n")
    r.bold = True
    p_st.add_run(
        "O EduQuiz Local é uma plataforma educacional interativa e gamificada desenvolvida no âmbito do Programa Institucional "
        "de Bolsas de Iniciação à Docência (PIBID) da Universidade Federal de Roraima (UFRR).\n\n"
        "Criado especialmente para solucionar o desafio da falta de conexão à internet nas escolas públicas brasileiras, o EduQuiz Local "
        "transforma o computador do professor em um servidor Wi-Fi local de alta performance. Os alunos jogam simultaneamente pelos seus "
        "próprios smartphones lendo um QR Code projetado na lousa, com latência inferior a 10 milissegundos e sem consumir 1 MB de dados móveis!\n\n"
        "PRINCIPAIS RECURSOS:\n"
        "• 100% Offline: Não depende de sinal de internet, fibra óptica ou servidores externos na nuvem.\n"
        "• Jogadores Ilimitados: Suporta turmas inteiras (40 a 50 celulares simultâneos) sem custos de assinatura.\n"
        "• Suporte a Imagens nas Questões: Adicione facilmente figuras geométricas, diagramas e gráficos matemáticos.\n"
        "• Efeitos Sonoros Originais: Áudio sintetizado via Web Audio API com contagem regressiva, bips e fanfarras.\n"
        "• Pódio Gamificado: Ranking dinâmico em tempo real com cálculo de pontuação por velocidade de resposta e confetes.\n"
        "• Privacidade Total (LGPD): Sem necessidade de cadastros, logins ou coleta de dados pessoais dos estudantes.\n\n"
        "Ideal para professores de Matemática, Ciências, História, Geografia e todas as disciplinas da Educação Básica!"
    )

    doc.add_paragraph().paragraph_format.space_after = Pt(12)

    # --- 4. Tabela de Ativos Prontos ---
    add_heading_1("4. Ativos de Imagem Pré-Gerados para a Submissão")
    p = doc.add_paragraph()
    p.add_run("Todos os ícones e logotipos em alta definição exigidos pela Microsoft Store já foram compilados e estão prontos na pasta do projeto:")

    asset_table = doc.add_table(rows=7, cols=3)
    asset_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    asset_table.columns[0].width = Inches(2.2)
    asset_table.columns[1].width = Inches(1.5)
    asset_table.columns[2].width = Inches(3.2)

    headers = ["Elemento Visual", "Resolução", "Arquivo Gerado no Projeto"]
    for i, h_text in enumerate(headers):
        cell_h = asset_table.rows[0].cells[i]
        set_cell_background(cell_h, "2B6CB0")
        set_cell_margins(cell_h, top=80, bottom=80, left=100, right=100)
        p = cell_h.paragraphs[0]
        r = p.add_run(h_text)
        r.bold = True
        r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        r.font.size = Pt(9.5)

    asset_rows = [
        ("Logotipo da Loja (StoreLogo)", "50 x 50 px", "msix_package/Assets/StoreLogo.png"),
        ("Ícone Quadrado Médio (Tile)", "150 x 150 px", "msix_package/Assets/Square150x150Logo.png"),
        ("Ícone Pequeno da Barra de Tarefas", "44 x 44 px", "msix_package/Assets/Square44x44Logo.png"),
        ("Ícone Retangular Largo (Wide Tile)", "310 x 150 px", "msix_package/Assets/Wide310x150Logo.png"),
        ("Ícone Grande do Menu Iniciar", "310 x 310 px", "msix_package/Assets/Square310x310Logo.png"),
        ("Tela de Abertura (SplashScreen)", "620 x 300 px", "msix_package/Assets/SplashScreen.png")
    ]

    for row_idx, data in enumerate(asset_rows, start=1):
        bg = "FFFFFF" if row_idx % 2 == 1 else "F7FAFC"
        for col_idx, text in enumerate(data):
            c = asset_table.rows[row_idx].cells[col_idx]
            set_cell_background(c, bg)
            set_cell_margins(c, top=60, bottom=60, left=100, right=100)
            p = c.paragraphs[0]
            r = p.add_run(text)
            r.font.size = Pt(9)
            if col_idx == 0:
                r.bold = True
            elif col_idx == 2:
                r.font.name = 'Consolas'
                r.font.size = Pt(8.5)
                r.font.color.rgb = RGBColor(0x80, 0x5A, 0xD5)

    doc.add_paragraph().paragraph_format.space_after = Pt(14)

    # --- 5. Checklist Final ---
    add_heading_1("5. Checklist de Verificação Antes do Envio")
    add_bullet("", "[  ] ", "Conta no Microsoft Partner Center ativa ($19 USD taxa única).")
    add_bullet("", "[  ] ", "Nome 'EduQuiz Local - PIBID Matemática UFRR' reservado com sucesso.")
    add_bullet("", "[  ] ", "Pacote .msix gerado pelo PWABuilder ou via AppxManifest.xml.")
    add_bullet("", "[  ] ", "URL da Política de Privacidade inserida (politica-privacidade.html).")
    add_bullet("", "[  ] ", "Questionário de Classificação Etária IARC preenchido (Livre / All Ages).")
    add_bullet("", "[  ] ", "Ficha da Loja preenchida com textos institucionais e capturas de tela.")
    add_bullet("", "[  ] ", "Clique final no botão 'Submit to the Store' (Enviar para a Loja).")

    # Save
    out_dir = os.path.join(os.path.dirname(__file__), '..', 'docs')
    if not os.path.exists(out_dir):
        os.makedirs(out_dir, exist_ok=True)
    out_docx = os.path.join(out_dir, 'Guia_Publicacao_Microsoft_Store.docx')
    doc.save(out_docx)
    print("[OK] Documento Word oficial gerado com sucesso em:", out_docx)

if __name__ == '__main__':
    create_guia_docx()
