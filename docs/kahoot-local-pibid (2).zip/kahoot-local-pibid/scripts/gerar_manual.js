const { execFile } = require('child_process');
const path = require('path');
const fs = require('fs');

const edgePaths = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
];

const edgeBin = edgePaths.find(p => fs.existsSync(p));
if (!edgeBin) {
  console.error('Navegador Edge/Chrome não encontrado.');
  process.exit(1);
}

const htmlPath = path.join(__dirname, '..', 'docs', 'manual_impressao.html');
const pdfPath = path.join(__dirname, '..', 'docs', 'Manual_EduQuiz_Local_PIBID.pdf');

const args = [
  '--headless',
  '--disable-gpu',
  '--no-pdf-header-footer',
  `--print-to-pdf=${pdfPath}`,
  htmlPath
];

console.log('Gerando PDF do Manual EduQuiz Local...');
execFile(edgeBin, args, (err) => {
  if (err) {
    console.error('Erro ao gerar PDF:', err);
    process.exit(1);
  }
  if (fs.existsSync(pdfPath)) {
    console.log('✅ PDF gerado com sucesso:', pdfPath);
    const siteDocs = path.join(__dirname, '..', '..', 'site-kahoot-clone', 'docs', 'Manual_EduQuiz_Local_PIBID.pdf');
    try {
      fs.copyFileSync(pdfPath, siteDocs);
      console.log('✅ PDF sincronizado com portal showcase.');
    } catch (e) {}
  } else {
    console.error('Arquivo PDF não foi criado.');
  }
});
