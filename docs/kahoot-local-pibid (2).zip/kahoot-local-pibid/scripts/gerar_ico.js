const fs = require('fs');
const path = require('path');

function createIcoFromPngs(pngBuffers) {
  const count = pngBuffers.length;
  const headerSize = 6;
  const dirEntrySize = 16;
  let offset = headerSize + (dirEntrySize * count);

  const header = Buffer.alloc(headerSize);
  header.writeUInt16LE(0, 0); // Reserved
  header.writeUInt16LE(1, 2); // Type 1 = ICO
  header.writeUInt16LE(count, 4); // Number of images

  const entries = [];
  const imageDatas = [];

  for (const png of pngBuffers) {
    // Read PNG width & height from IHDR chunk (bytes 16..23)
    let width = png.readUInt32BE(16);
    let height = png.readUInt32BE(20);
    const size = png.length;

    const entry = Buffer.alloc(dirEntrySize);
    entry.writeUInt8(width >= 256 ? 0 : width, 0); // Width (0 means 256)
    entry.writeUInt8(height >= 256 ? 0 : height, 1); // Height (0 means 256)
    entry.writeUInt8(0, 2); // Color palette
    entry.writeUInt8(0, 3); // Reserved
    entry.writeUInt16LE(1, 4); // Color planes
    entry.writeUInt16LE(32, 6); // Bits per pixel
    entry.writeUInt32LE(size, 8); // Size of image data
    entry.writeUInt32LE(offset, 12); // Offset of image data

    entries.push(entry);
    imageDatas.push(png);
    offset += size;
  }

  return Buffer.concat([header, ...entries, ...imageDatas]);
}

const assetsDir = path.join(__dirname, '..', 'msix_package', 'Assets');
const iconsDir = path.join(__dirname, '..', 'public', 'icons');

const sizes = [
  path.join(assetsDir, 'Square44x44Logo.targetsize-24.png'),
  path.join(assetsDir, 'Square44x44Logo.png'),
  path.join(assetsDir, 'Square44x44Logo.targetsize-48.png'),
  path.join(assetsDir, 'Square150x150Logo.png'),
  path.join(assetsDir, 'Square44x44Logo.targetsize-256.png')
];

const pngBuffers = sizes
  .filter(p => fs.existsSync(p))
  .map(p => fs.readFileSync(p));

if (pngBuffers.length > 0) {
  const icoBuffer = createIcoFromPngs(pngBuffers);
  const outIco1 = path.join(__dirname, '..', 'app.ico');
  const outIco2 = path.join(iconsDir, 'app.ico');
  fs.writeFileSync(outIco1, icoBuffer);
  fs.writeFileSync(outIco2, icoBuffer);
  console.log(`[OK] app.ico gerado com sucesso (${icoBuffer.length} bytes) contendo ${pngBuffers.length} resolucoes.`);
} else {
  console.error('Nenhum arquivo PNG encontrado para compor o ICO.');
}
