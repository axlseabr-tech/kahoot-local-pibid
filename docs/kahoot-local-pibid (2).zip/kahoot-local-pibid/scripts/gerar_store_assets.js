const { execFileSync } = require('child_process');
const path = require('path');
const fs = require('fs');

const edgePaths = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
];

const edgeBin = edgePaths.find(p => fs.existsSync(p));
if (!edgeBin) {
  console.error('Navegador Edge/Chrome não encontrado.');
  process.exit(1);
}

const iconsDir = path.join(__dirname, '..', 'public', 'icons');
if (!fs.existsSync(iconsDir)) fs.mkdirSync(iconsDir, { recursive: true });

const storeDir = path.join(__dirname, '..', 'msix_package', 'Assets');
if (!fs.existsSync(storeDir)) fs.mkdirSync(storeDir, { recursive: true });

const svgPath = path.join(iconsDir, 'icon.svg');
const svgContent = fs.readFileSync(svgPath, 'utf8');

// List of assets to generate
const assets = [
  { name: 'icon-192.png', width: 192, height: 192, target: iconsDir },
  { name: 'icon-512.png', width: 512, height: 512, target: iconsDir },
  { name: 'StoreLogo.png', width: 50, height: 50, target: storeDir },
  { name: 'Square44x44Logo.png', width: 44, height: 44, target: storeDir },
  { name: 'Square44x44Logo.targetsize-24.png', width: 24, height: 24, target: storeDir },
  { name: 'Square44x44Logo.targetsize-48.png', width: 48, height: 48, target: storeDir },
  { name: 'Square44x44Logo.targetsize-256.png', width: 256, height: 256, target: storeDir },
  { name: 'Square150x150Logo.png', width: 150, height: 150, target: storeDir },
  { name: 'Square310x310Logo.png', width: 310, height: 310, target: storeDir },
  { name: 'Wide310x150Logo.png', width: 310, height: 150, target: storeDir, isWide: true },
  { name: 'SplashScreen.png', width: 620, height: 300, target: storeDir, isWide: true }
];

console.log('Gerando ativos de imagem para Microsoft Store & PWA...');

assets.forEach(asset => {
  let html;
  if (asset.isWide) {
    html = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    width: ${asset.width}px;
    height: ${asset.height}px;
    background: #1a0b2e;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
  }
  .icon-wrap {
    width: ${Math.round(asset.height * 0.8)}px;
    height: ${Math.round(asset.height * 0.8)}px;
  }
  svg { width: 100%; height: 100%; }
</style>
</head>
<body>
  <div class="icon-wrap">
    ${svgContent}
  </div>
</body>
</html>`;
  } else {
    html = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    width: ${asset.width}px;
    height: ${asset.height}px;
    background: transparent;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
  }
  svg { width: 100%; height: 100%; }
</style>
</head>
<body>
  ${svgContent}
</body>
</html>`;
  }

  const tempHtml = path.join(__dirname, `temp_${asset.width}x${asset.height}.html`);
  const outFile = path.join(asset.target, asset.name);
  fs.writeFileSync(tempHtml, html, 'utf8');

  try {
    execFileSync(edgeBin, [
      '--headless',
      '--disable-gpu',
      `--window-size=${asset.width},${asset.height}`,
      '--hide-scrollbars',
      `--screenshot=${outFile}`,
      tempHtml
    ]);
    console.log(`✅ [${asset.width}x${asset.height}] Gerado: ${asset.name}`);
  } catch (e) {
    console.error(`❌ Falha ao gerar ${asset.name}:`, e.message);
  } finally {
    if (fs.existsSync(tempHtml)) fs.unlinkSync(tempHtml);
  }
});

console.log('✅ Todos os ativos de ícones foram gerados com sucesso!');
