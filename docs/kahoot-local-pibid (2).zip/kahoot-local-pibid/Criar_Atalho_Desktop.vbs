Set oWS = WScript.CreateObject("WScript.Shell")
sLinkFile = oWS.SpecialFolders("Desktop") & "\EduQuiz Local.lnk"
Set oLink = oWS.CreateShortcut(sLinkFile)
sCurrentDir = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)

oLink.TargetPath = sCurrentDir & "\EduQuiz.exe"
oLink.WorkingDirectory = sCurrentDir
oLink.Description = "EduQuiz Local - PIBID Matematica UFRR"
oLink.IconLocation = sCurrentDir & "\app.ico, 0"
oLink.Save

MsgBox "Atalho do EduQuiz Local criado com sucesso na sua Area de Trabalho!", 64, "EduQuiz Local - PIBID UFRR"
