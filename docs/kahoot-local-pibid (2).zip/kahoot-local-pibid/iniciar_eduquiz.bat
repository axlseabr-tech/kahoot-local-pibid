@echo off
chcp 65001 > nul
title EduQuiz Local - Servidor & Aplicativo
cls
echo ========================================================
echo   🎓 EDUQUIZ LOCAL - PIBID MATEMATICA UFRR
echo   Plataforma Gamificada de Quiz 100%% Offline
echo ========================================================
echo.
echo [1/2] Iniciando o servidor local na porta 3000...
start /B node server.js

timeout /t 2 /nobreak > nul

echo [2/2] Abrindo o EduQuiz no Microsoft Edge (Modo App)...
start msedge --app="http://localhost:3000/host.html" 2>nul || start http://localhost:3000/host.html

echo.
echo ✅ EduQuiz Local em execucao!
echo 💡 Para fechar, basta fechar esta janela.
echo.
pause
