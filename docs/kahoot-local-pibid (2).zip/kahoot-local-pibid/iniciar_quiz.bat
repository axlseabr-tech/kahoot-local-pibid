@echo off
call "%~dp0iniciar_eduquiz.bat"

