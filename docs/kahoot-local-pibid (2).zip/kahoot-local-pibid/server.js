const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const os = require('os');
const path = require('path');
const fs = require('fs');
const QRCode = require('qrcode');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;
const QUIZZES_DIR = path.join(__dirname, 'quizzes');
const UPLOADS_DIR = path.join(__dirname, 'public', 'uploads');

if (!fs.existsSync(QUIZZES_DIR)) {
  fs.mkdirSync(QUIZZES_DIR, { recursive: true });
}

if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// API: Upload de Imagem (Base64 / Data URL)
app.post('/api/upload-image', (req, res) => {
  try {
    const { image, filename } = req.body;
    if (!image) {
      return res.status(400).json({ error: 'Nenhuma imagem fornecida.' });
    }

    let base64Data = image;
    let ext = 'png';
    const matches = image.match(/^data:([A-Za-z0-9-+.\/]+);base64,(.+)$/);
    if (matches && matches.length === 3) {
      const mime = matches[1];
      base64Data = matches[2];
      if (mime.includes('jpeg') || mime.includes('jpg')) ext = 'jpg';
      else if (mime.includes('gif')) ext = 'gif';
      else if (mime.includes('webp')) ext = 'webp';
      else if (mime.includes('svg')) ext = 'svg';
      else ext = 'png';
    } else if (filename && filename.includes('.')) {
      ext = filename.split('.').pop().toLowerCase();
    }

    const uniqueName = `img-${Date.now()}-${Math.random().toString(36).substring(2, 8)}.${ext}`;
    const filePath = path.join(UPLOADS_DIR, uniqueName);
    const buffer = Buffer.from(base64Data, 'base64');

    fs.writeFileSync(filePath, buffer);
    res.json({ success: true, url: `/uploads/${uniqueName}` });
  } catch (err) {
    console.error('Erro ao salvar imagem:', err);
    res.status(500).json({ error: 'Erro ao salvar arquivo de imagem.' });
  }
});

// Detect local IPv4 addresses (Wi-Fi, Ethernet, Hotspot), ignoring VPN virtual adapters
function getLocalIPs() {
  const interfaces = os.networkInterfaces();
  const addresses = [];

  const vpnKeywords = ['radmin', 'hamachi', 'virtualbox', 'vmware', 'vethernet', 'tap', 'wsl', 'loopback'];

  for (const name of Object.keys(interfaces)) {
    const lowerName = name.toLowerCase();
    const isVpn = vpnKeywords.some(kw => lowerName.includes(kw));

    for (const net of interfaces[name]) {
      // IPv4 and not internal 127.0.0.1
      if (net.family === 'IPv4' && !net.internal) {
        const isHotspot = net.address.startsWith('192.168.137.') || lowerName.includes('hotspot');
        const isWifi = lowerName.includes('wi-fi') || lowerName.includes('wlan') || lowerName.includes('wireless');
        
        let priority = 1;
        if (isHotspot) priority = 10;
        else if (isWifi) priority = 8;
        else if (isVpn) priority = 0; // Low priority for VPNs
        else priority = 5;

        addresses.push({
          interface: name,
          address: net.address,
          isHotspot,
          isWifi,
          isVpn,
          priority
        });
      }
    }
  }

  // Sort by priority descending
  addresses.sort((a, b) => b.priority - a.priority);
  return addresses;
}

// API: Obter IPs locais e URL recomendada
app.get('/api/network', (req, res) => {
  const ips = getLocalIPs();
  const primaryIP = ips.length > 0 ? ips[0].address : 'localhost';
  res.json({
    primaryIP,
    port: PORT,
    fullUrl: `http://${primaryIP}:${PORT}`,
    allInterfaces: ips
  });
});

// API: Gerar QR Code em Data URL
app.get('/api/qrcode', async (req, res) => {
  try {
    const text = req.query.text || `http://localhost:${PORT}`;
    const qrDataUrl = await QRCode.toDataURL(text, {
      width: 320,
      margin: 2,
      color: {
        dark: '#1a103c',
        light: '#ffffff'
      }
    });
    res.json({ dataUrl: qrDataUrl });
  } catch (err) {
    res.status(500).json({ error: 'Erro ao gerar QR code' });
  }
});

// API: Listar Quizzes
app.get('/api/quizzes', (req, res) => {
  try {
    const files = fs.readdirSync(QUIZZES_DIR).filter(f => f.endsWith('.json'));
    const list = files.map(file => {
      const content = fs.readFileSync(path.join(QUIZZES_DIR, file), 'utf8');
      const data = JSON.parse(content);
      return {
        id: data.id || file.replace('.json', ''),
        filename: file,
        title: data.title || file,
        description: data.description || '',
        questionCount: Array.isArray(data.questions) ? data.questions.length : 0
      };
    });
    res.json(list);
  } catch (err) {
    res.status(500).json({ error: 'Erro ao listar quizzes' });
  }
});

// API: Obter Quiz específico
app.get('/api/quizzes/:id', (req, res) => {
  try {
    const filePath = path.join(QUIZZES_DIR, `${req.params.id}.json`);
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'Quiz não encontrado' });
    }
    const content = fs.readFileSync(filePath, 'utf8');
    res.json(JSON.parse(content));
  } catch (err) {
    res.status(500).json({ error: 'Erro ao ler quiz' });
  }
});

// API: Salvar Quiz
app.post('/api/quizzes', (req, res) => {
  try {
    const quiz = req.body;
    if (!quiz.title || !Array.isArray(quiz.questions) || quiz.questions.length === 0) {
      return res.status(400).json({ error: 'Quiz precisa de título e ao menos 1 pergunta.' });
    }
    const id = quiz.id || quiz.title.toLowerCase().replace(/[^a-z0-9]/g, '-').slice(0, 30) + '-' + Date.now().toString().slice(-4);
    quiz.id = id;
    fs.writeFileSync(path.join(QUIZZES_DIR, `${id}.json`), JSON.stringify(quiz, null, 2), 'utf8');
    res.json({ success: true, id, quiz });
  } catch (err) {
    res.status(500).json({ error: 'Erro ao salvar quiz' });
  }
});

// Gerenciamento de Salas e Jogos em Memória
const activeGames = new Map(); // PIN -> GameState

function generatePIN() {
  let pin;
  do {
    pin = Math.floor(100000 + Math.random() * 900000).toString();
  } while (activeGames.has(pin));
  return pin;
}

io.on('connection', (socket) => {
  // HOST: Criar novo jogo
  socket.on('host_create_game', ({ quizId }) => {
    try {
      const filePath = path.join(QUIZZES_DIR, `${quizId}.json`);
      if (!fs.existsSync(filePath)) {
        return socket.emit('error_message', 'Quiz selecionado não existe.');
      }
      const quiz = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      const pin = generatePIN();

      const game = {
        pin,
        hostSocketId: socket.id,
        quiz,
        currentIndex: 0,
        state: 'LOBBY', // LOBBY, INTRO, QUESTION, REVEAL, LEADERBOARD, PODIUM
        questionStartTime: 0,
        players: new Map(), // socket.id -> player info
        answersReceived: new Map() // socket.id -> { optionIndex, timeTaken, points }
      };

      activeGames.set(pin, game);
      socket.join(`game:${pin}`);
      socket.emit('game_created', { pin, quizTitle: quiz.title, totalQuestions: quiz.questions.length });
    } catch (e) {
      socket.emit('error_message', 'Erro ao inicializar jogo.');
    }
  });

  // PLAYER: Entrar no jogo
  socket.on('player_join', ({ pin, nickname }) => {
    const game = activeGames.get(pin);
    if (!game) {
      return socket.emit('join_error', 'PIN do jogo não encontrado. Verifique na tela do projetor!');
    }
    if (game.state !== 'LOBBY') {
      return socket.emit('join_error', 'Este jogo já começou! Espere a próxima partida.');
    }

    const cleanNick = (nickname || '').trim().slice(0, 15);
    if (!cleanNick) {
      return socket.emit('join_error', 'Por favor, digite um nome válido.');
    }

    // Verificar colisão de nomes
    for (const player of game.players.values()) {
      if (player.nickname.toLowerCase() === cleanNick.toLowerCase()) {
        return socket.emit('join_error', 'Esse nome já está em uso nesta sala! Escolha outro.');
      }
    }

    const newPlayer = {
      id: socket.id,
      pin,
      nickname: cleanNick,
      score: 0,
      streak: 0,
      lastAnswer: null
    };

    game.players.set(socket.id, newPlayer);
    socket.join(`game:${pin}`);
    socket.gamePIN = pin;

    // Confirma para o jogador
    socket.emit('joined_successfully', {
      pin,
      nickname: cleanNick,
      quizTitle: game.quiz.title
    });

    // Notifica o Host com lista atualizada
    const playerList = Array.from(game.players.values()).map(p => ({
      id: p.id,
      nickname: p.nickname
    }));

    io.to(game.hostSocketId).emit('player_list_update', {
      count: playerList.length,
      players: playerList
    });
  });

  // HOST: Iniciar o jogo (da Lobby para Primeira Pergunta)
  socket.on('host_start_game', () => {
    const game = findGameByHost(socket.id);
    if (!game || game.players.size === 0) {
      return socket.emit('error_message', 'Aguarde ao menos um aluno entrar na sala!');
    }

    game.currentIndex = 0;
    startQuestionIntro(game);
  });

  function startQuestionIntro(game) {
    game.state = 'INTRO';
    game.answersReceived.clear();
    const currentQ = game.quiz.questions[game.currentIndex];

    // Transmite contagem regressiva de 3s para o Host e Alunos
    io.to(`game:${game.pin}`).emit('question_intro', {
      questionNumber: game.currentIndex + 1,
      totalQuestions: game.quiz.questions.length,
      questionText: currentQ.question,
      timeLimit: currentQ.time || 20
    });

    setTimeout(() => {
      if (game.state === 'INTRO') {
        startQuestionActive(game);
      }
    }, 3500);
  }

  function startQuestionActive(game) {
    game.state = 'QUESTION';
    game.questionStartTime = Date.now();
    const currentQ = game.quiz.questions[game.currentIndex];

    // Host recebe detalhes completos com texto das alternativas e imagem (se houver)
    io.to(game.hostSocketId).emit('question_active_host', {
      questionNumber: game.currentIndex + 1,
      totalQuestions: game.quiz.questions.length,
      questionText: currentQ.question,
      image: currentQ.image || null,
      options: currentQ.options,
      timeLimit: currentQ.time || 20,
      totalPlayers: game.players.size
    });

    // Alunos recebem aviso para poderem clicar nos 4 botões coloridos
    socket.to(`game:${game.pin}`).emit('question_active_player', {
      questionNumber: game.currentIndex + 1,
      timeLimit: currentQ.time || 20
    });
  }

  // PLAYER: Enviar resposta
  socket.on('player_submit_answer', ({ optionIndex }) => {
    const game = activeGames.get(socket.gamePIN);
    if (!game || game.state !== 'QUESTION') return;
    if (game.answersReceived.has(socket.id)) return; // Já respondeu

    const currentQ = game.quiz.questions[game.currentIndex];
    const timeTaken = Math.max(50, Date.now() - game.questionStartTime);
    const durationMs = (currentQ.time || 20) * 1000;
    const isCorrect = optionIndex === currentQ.correctIndex;

    let points = 0;
    const player = game.players.get(socket.id);

    if (isCorrect && player) {
      // Fórmula pedagógica gamificada: pontos baseados na velocidade de acerto
      const maxPoints = currentQ.points || 1000;
      const speedRatio = Math.max(0, 1 - (timeTaken / durationMs) / 2);
      points = Math.round(maxPoints * speedRatio);

      player.streak = (player.streak || 0) + 1;
      if (player.streak > 1) {
        points += Math.min(500, (player.streak - 1) * 100); // Bônus de sequência
      }
      player.score += points;
    } else if (player) {
      player.streak = 0;
    }

    const answerRecord = {
      optionIndex,
      timeTaken,
      isCorrect,
      points,
      totalScore: player ? player.score : 0
    };

    game.answersReceived.set(socket.id, answerRecord);

    // Confirmação para o jogador que a resposta foi recebida
    socket.emit('answer_acknowledged', { received: true });

    // Atualiza contagem de respostas no Host
    io.to(game.hostSocketId).emit('answers_count_update', {
      received: game.answersReceived.size,
      total: game.players.size
    });

    // Se todos responderam antes do tempo, encerra a pergunta imediatamente
    if (game.answersReceived.size >= game.players.size) {
      revealAnswers(game);
    }
  });

  // HOST: Tempo esgotado
  socket.on('host_time_up', () => {
    const game = findGameByHost(socket.id);
    if (game && game.state === 'QUESTION') {
      revealAnswers(game);
    }
  });

  function revealAnswers(game) {
    if (game.state !== 'QUESTION') return;
    game.state = 'REVEAL';

    const currentQ = game.quiz.questions[game.currentIndex];
    const counts = [0, 0, 0, 0];

    for (const ans of game.answersReceived.values()) {
      if (ans.optionIndex >= 0 && ans.optionIndex < 4) {
        counts[ans.optionIndex]++;
      }
    }

    // Notifica Host com o resultado estatístico da pergunta
    io.to(game.hostSocketId).emit('question_reveal_host', {
      correctIndex: currentQ.correctIndex,
      explanation: currentQ.explanation || '',
      counts,
      totalAnswers: game.answersReceived.size
    });

    // Notifica cada aluno individualmente com seu feedback
    for (const [playerId, player] of game.players.entries()) {
      const ans = game.answersReceived.get(playerId);
      const isCorrect = ans ? ans.isCorrect : false;
      const points = ans ? ans.points : 0;

      io.to(playerId).emit('question_reveal_player', {
        isCorrect,
        points,
        streak: player.streak,
        totalScore: player.score,
        correctIndex: currentQ.correctIndex
      });
    }
  }

  // HOST: Avançar (de Reveal para Leaderboard ou Próxima Pergunta)
  socket.on('host_next_step', () => {
    const game = findGameByHost(socket.id);
    if (!game) return;

    if (game.state === 'REVEAL') {
      // Vai para o Placar (Leaderboard)
      game.state = 'LEADERBOARD';

      const sortedPlayers = Array.from(game.players.values())
        .sort((a, b) => b.score - a.score);

      const top5 = sortedPlayers.slice(0, 5).map((p, idx) => ({
        rank: idx + 1,
        nickname: p.nickname,
        score: p.score,
        streak: p.streak
      }));

      // Host recebe top 5
      io.to(game.hostSocketId).emit('leaderboard_host', {
        leaderboard: top5,
        isLastQuestion: game.currentIndex + 1 >= game.quiz.questions.length
      });

      // Aluno recebe sua posição e distância do topo
      sortedPlayers.forEach((p, idx) => {
        io.to(p.id).emit('leaderboard_player', {
          rank: idx + 1,
          totalPlayers: sortedPlayers.length,
          score: p.score
        });
      });

    } else if (game.state === 'LEADERBOARD') {
      if (game.currentIndex + 1 < game.quiz.questions.length) {
        // Próxima pergunta
        game.currentIndex++;
        startQuestionIntro(game);
      } else {
        // Fim de jogo: Pódio final
        game.state = 'PODIUM';

        const podium = Array.from(game.players.values())
          .sort((a, b) => b.score - a.score);

        io.to(game.hostSocketId).emit('game_podium_host', {
          podium: podium.slice(0, 3).map((p, idx) => ({
            rank: idx + 1,
            nickname: p.nickname,
            score: p.score
          })),
          totalPlayers: podium.length
        });

        podium.forEach((p, idx) => {
          io.to(p.id).emit('game_podium_player', {
            rank: idx + 1,
            score: p.score,
            totalPlayers: podium.length
          });
        });
      }
    }
  });

  // Desconexão
  socket.on('disconnect', () => {
    // Se for um host, encerra o jogo
    for (const [pin, game] of activeGames.entries()) {
      if (game.hostSocketId === socket.id) {
        io.to(`game:${pin}`).emit('game_ended_by_host');
        activeGames.delete(pin);
        break;
      } else if (game.players.has(socket.id)) {
        game.players.delete(socket.id);
        const playerList = Array.from(game.players.values()).map(p => ({
          id: p.id,
          nickname: p.nickname
        }));
        io.to(game.hostSocketId).emit('player_list_update', {
          count: playerList.length,
          players: playerList
        });
        break;
      }
    }
  });
});

function findGameByHost(socketId) {
  for (const game of activeGames.values()) {
    if (game.hostSocketId === socketId) {
      return game;
    }
  }
  return null;
}

server.listen(PORT, '0.0.0.0', () => {
  const ips = getLocalIPs();
  console.log('\n======================================================');
  console.log('🎓 EDUQUIZ LOCAL - PLATAFORMA DE QUIZ OFFLINE (PIBID UFRR)');
  console.log('======================================================');
  console.log(`💻 Painel do Professor (Host): http://localhost:${PORT}/host.html`);
  console.log(`📱 Acesso dos alunos no celular:`);
  if (ips.length > 0) {
    ips.forEach(ip => {
      const tag = ip.isHotspot ? ' [Ponto de Acesso Móvel]' : '';
      console.log(`   👉 http://${ip.address}:${PORT}${tag}`);
    });
  } else {
    console.log(`   👉 Conecte o notebook ao Wi-Fi ou ligue o Ponto de Acesso Móvel.`);
  }
  console.log('======================================================\n');
});
