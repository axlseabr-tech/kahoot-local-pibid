const socket = io();

// Elementos de Telas
const screenSelect = document.getElementById('screen-select-quiz');
const screenLobby = document.getElementById('screen-lobby');
const screenIntro = document.getElementById('screen-intro');
const screenQuestion = document.getElementById('screen-question');
const screenLeaderboard = document.getElementById('screen-leaderboard');
const screenPodium = document.getElementById('screen-podium');

// Controles e Botões
const selectQuizList = document.getElementById('select-quiz-list');
const btnCreateLobby = document.getElementById('btn-create-lobby');
const btnStartGame = document.getElementById('btn-start-game');
const btnNextStep = document.getElementById('btn-next-step');
const btnNextQuestion = document.getElementById('btn-next-question');
const btnRestartGame = document.getElementById('btn-restart-game');
const btnSoundToggle = document.getElementById('btn-sound-toggle');

// Elementos do Lobby
const lobbyPin = document.getElementById('lobby-pin');
const hostNetworkUrl = document.getElementById('host-network-url');
const lobbyQrImg = document.getElementById('lobby-qr-img');
const lobbyPlayerCount = document.getElementById('lobby-player-count');
const lobbyPlayersGrid = document.getElementById('lobby-players-grid');

// Elementos da Pergunta
const qCounterLabel = document.getElementById('q-counter-label');
const qTimer = document.getElementById('q-timer');
const qAnswersCount = document.getElementById('q-answers-count');
const qTitle = document.getElementById('q-title');
const qImageContainer = document.getElementById('q-image-container');
const qImage = document.getElementById('q-image');
const hostRevealBar = document.getElementById('host-reveal-bar');
const qExplanation = document.getElementById('q-explanation');

let timerInterval = null;
let currentSeconds = 20;
let currentPIN = null;
let isSoundMuted = false;

const selectNetworkAdapter = document.getElementById('select-network-adapter');

let currentNetworkData = null;

// Inicialização: carregar rede e quizzes
async function initHost() {
  try {
    // 1. Obter informações de rede
    const netRes = await fetch('/api/network');
    currentNetworkData = await netRes.json();
    hostNetworkUrl.textContent = currentNetworkData.fullUrl;

    // Preencher dropdown de interfaces de rede
    selectNetworkAdapter.innerHTML = '';
    currentNetworkData.allInterfaces.forEach((iface, i) => {
      const opt = document.createElement('option');
      const tag = iface.isHotspot ? ' (Hotspot do Windows)' : iface.isWifi ? ' (Wi-Fi)' : '';
      opt.value = iface.address;
      opt.textContent = `${iface.interface}: ${iface.address}${tag}`;
      if (i === 0) opt.selected = true;
      selectNetworkAdapter.appendChild(opt);
    });

    selectNetworkAdapter.addEventListener('change', async () => {
      const selectedIP = selectNetworkAdapter.value;
      const port = currentNetworkData.port || 3000;
      const newUrl = `http://${selectedIP}:${port}`;
      hostNetworkUrl.textContent = newUrl;

      if (currentPIN) {
        await updateLobbyQRCode(newUrl, currentPIN);
      }
    });

    // 2. Obter lista de quizzes
    const quizRes = await fetch('/api/quizzes');
    const quizzes = await quizRes.json();
    
    selectQuizList.innerHTML = '';
    quizzes.forEach(q => {
      const opt = document.createElement('option');
      opt.value = q.id;
      opt.textContent = `${q.title} (${q.questionCount} perguntas)`;
      selectQuizList.appendChild(opt);
    });
  } catch (err) {
    console.error('Erro na inicialização:', err);
  }
}

initHost();

async function updateLobbyQRCode(baseUrl, pin) {
  try {
    const joinUrl = `${baseUrl}/index.html?pin=${pin}`;
    const qrRes = await fetch(`/api/qrcode?text=${encodeURIComponent(joinUrl)}`);
    const qrData = await qrRes.json();
    lobbyQrImg.src = qrData.dataUrl;
  } catch (e) {
    console.error('Erro ao atualizar QR Code:', e);
  }
}

// Alternar som
btnSoundToggle.addEventListener('click', () => {
  isSoundMuted = !isSoundMuted;
  window.soundEffects.isMuted = isSoundMuted;
  btnSoundToggle.textContent = isSoundMuted ? '🔇' : '🔊';
  if (isSoundMuted) {
    window.soundEffects.stopLobbyMusic();
  }
});

// Criar Sala de Jogo (Lobby)
btnCreateLobby.addEventListener('click', () => {
  const quizId = selectQuizList.value;
  if (!quizId) return alert('Selecione um quiz válido.');
  
  socket.emit('host_create_game', { quizId });
});

// Callback: Jogo criado com PIN
socket.on('game_created', async ({ pin }) => {
  currentPIN = pin;
  lobbyPin.textContent = pin;

  const currentUrl = hostNetworkUrl.textContent;
  await updateLobbyQRCode(currentUrl, pin);

  showScreen(screenLobby);
  window.soundEffects.startLobbyMusic();
});

// Atualização de jogadores no Lobby
socket.on('player_list_update', ({ count, players }) => {
  lobbyPlayerCount.textContent = `👥 ${count} ${count === 1 ? 'Aluno Conectado' : 'Alunos Conectados'}`;
  lobbyPlayersGrid.innerHTML = '';

  players.forEach(p => {
    const card = document.createElement('div');
    card.className = 'player-card';
    card.textContent = p.nickname;
    lobbyPlayersGrid.appendChild(card);
  });

  btnStartGame.disabled = count === 0;
});

// Host inicia o jogo
btnStartGame.addEventListener('click', () => {
  window.soundEffects.stopLobbyMusic();
  socket.emit('host_start_game');
});

// Intro da Pergunta (3 segundos de preparação)
socket.on('question_intro', ({ questionNumber, totalQuestions, questionText }) => {
  showScreen(screenIntro);
  document.getElementById('intro-question-num').textContent = `Pergunta ${questionNumber} de ${totalQuestions}`;
  document.getElementById('intro-question-text').textContent = questionText;
  
  let count = 3;
  const countEl = document.getElementById('intro-countdown');
  countEl.textContent = count;
  window.soundEffects.playTick();

  const countInterval = setInterval(() => {
    count--;
    if (count > 0) {
      countEl.textContent = count;
      window.soundEffects.playTick();
    } else {
      clearInterval(countInterval);
    }
  }, 1000);
});

// Pergunta ativa
socket.on('question_active_host', ({ questionNumber, totalQuestions, questionText, image, options, timeLimit, totalPlayers }) => {
  showScreen(screenQuestion);
  resetOptionsStyles();
  hostRevealBar.classList.add('hidden');

  qCounterLabel.textContent = `Pergunta ${questionNumber} de ${totalQuestions}`;
  qTitle.textContent = questionText;
  qAnswersCount.textContent = `0 / ${totalPlayers} responderam`;

  // Configurar Imagem da Questão (se houver)
  if (image) {
    qImage.src = image;
    qImageContainer.classList.remove('hidden');
    screenQuestion.classList.add('has-image');
  } else {
    qImage.src = '';
    qImageContainer.classList.add('hidden');
    screenQuestion.classList.remove('has-image');
  }

  // Preencher textos das 4 opções
  for (let i = 0; i < 4; i++) {
    const txtEl = document.getElementById(`opt-text-${i}`);
    if (txtEl) {
      txtEl.textContent = options[i] || '-';
    }
  }

  // Iniciar Cronômetro
  currentSeconds = timeLimit;
  updateTimerDisplay(currentSeconds);

  if (timerInterval) clearInterval(timerInterval);
  timerInterval = setInterval(() => {
    currentSeconds--;
    updateTimerDisplay(currentSeconds);

    if (currentSeconds <= 5 && currentSeconds > 0) {
      window.soundEffects.playUrgentTick();
    } else if (currentSeconds > 0) {
      window.soundEffects.playTick();
    } else {
      clearInterval(timerInterval);
      socket.emit('host_time_up');
    }
  }, 1000);
});

function updateTimerDisplay(sec) {
  qTimer.textContent = sec;
  if (sec <= 5) {
    qTimer.classList.add('urgent');
  } else {
    qTimer.classList.remove('urgent');
  }
}

// Atualização de respostas recebidas em tempo real
socket.on('answers_count_update', ({ received, total }) => {
  qAnswersCount.textContent = `${received} / ${total} responderam`;
});

// Revelação da resposta correta
socket.on('question_reveal_host', ({ correctIndex, explanation, counts }) => {
  if (timerInterval) clearInterval(timerInterval);

  window.soundEffects.playCorrect();

  // Destacar opção correta e esmaecer as erradas
  for (let i = 0; i < 4; i++) {
    const box = document.getElementById(`opt-${i}`);
    const countTag = document.getElementById(`opt-count-${i}`);
    
    countTag.textContent = `${counts[i]} ${counts[i] === 1 ? 'voto' : 'votos'}`;
    countTag.classList.remove('hidden');

    if (i === correctIndex) {
      box.classList.add('highlight-correct');
    } else {
      box.classList.add('dimmed');
    }
  }

  if (explanation) {
    qExplanation.textContent = `💡 Explicação: ${explanation}`;
  } else {
    qExplanation.textContent = '';
  }

  hostRevealBar.classList.remove('hidden');
});

// Avançar para Placar
btnNextStep.addEventListener('click', () => {
  socket.emit('host_next_step');
});

// Exibir Placar de Líderes (Leaderboard)
socket.on('leaderboard_host', ({ leaderboard, isLastQuestion }) => {
  showScreen(screenLeaderboard);
  const listEl = document.getElementById('leaderboard-list');
  listEl.innerHTML = '';

  leaderboard.forEach(p => {
    const item = document.createElement('div');
    item.className = `leaderboard-item ${p.rank === 1 ? 'rank-1' : ''}`;
    item.innerHTML = `
      <span class="rank">#${p.rank}</span>
      <span class="name">${p.nickname} ${p.streak > 1 ? `🔥 (${p.streak})` : ''}</span>
      <span class="score">${p.score} pts</span>
    `;
    listEl.appendChild(item);
  });

  btnNextQuestion.textContent = isLastQuestion ? 'Ver Pódio Final 🏆' : 'Próxima Pergunta ➔';
});

btnNextQuestion.addEventListener('click', () => {
  socket.emit('host_next_step');
});

// Pódio Final
socket.on('game_podium_host', ({ podium }) => {
  showScreen(screenPodium);
  window.confetti.start();
  window.soundEffects.playPodiumFanfare();

  // 1º Lugar
  if (podium[0]) {
    document.getElementById('podium-name-1').textContent = podium[0].nickname;
    document.getElementById('podium-score-1').textContent = `${podium[0].score} pts`;
  }
  // 2º Lugar
  if (podium[1]) {
    document.getElementById('podium-name-2').textContent = podium[1].nickname;
    document.getElementById('podium-score-2').textContent = `${podium[1].score} pts`;
  }
  // 3º Lugar
  if (podium[2]) {
    document.getElementById('podium-name-3').textContent = podium[2].nickname;
    document.getElementById('podium-score-3').textContent = `${podium[2].score} pts`;
  }
});

btnRestartGame.addEventListener('click', () => {
  window.confetti.stop();
  window.location.reload();
});

// Troca de telas auxiliares
function showScreen(screenToShow) {
  [screenSelect, screenLobby, screenIntro, screenQuestion, screenLeaderboard, screenPodium].forEach(s => {
    s.classList.add('hidden');
  });
  screenToShow.classList.remove('hidden');
}

function resetOptionsStyles() {
  for (let i = 0; i < 4; i++) {
    const box = document.getElementById(`opt-${i}`);
    const countTag = document.getElementById(`opt-count-${i}`);
    box.classList.remove('highlight-correct', 'dimmed');
    countTag.classList.add('hidden');
  }
}
