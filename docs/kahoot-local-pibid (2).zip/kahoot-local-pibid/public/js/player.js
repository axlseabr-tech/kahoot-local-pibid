const socket = io();

// Telas do Aluno
const screenJoin = document.getElementById('player-screen-join');
const screenWaiting = document.getElementById('player-screen-waiting');
const screenGame = document.getElementById('player-screen-game');
const screenSent = document.getElementById('player-screen-sent');
const screenFeedback = document.getElementById('player-screen-feedback');
const screenRank = document.getElementById('player-screen-rank');

// Inputs e Botões
const inputPin = document.getElementById('input-pin');
const inputNickname = document.getElementById('input-nickname');
const btnPlayerJoin = document.getElementById('btn-player-join');
const joinErrorMsg = document.getElementById('join-error-msg');
const optionButtons = document.querySelectorAll('.player-btn');

// Elementos de Feedback
const feedbackCard = document.getElementById('feedback-card');
const feedbackIcon = document.getElementById('feedback-icon');
const feedbackTitle = document.getElementById('feedback-title');
const feedbackPoints = document.getElementById('feedback-points');
const feedbackStreak = document.getElementById('feedback-streak');
const feedbackTotal = document.getElementById('feedback-total');
const playerRankDisplay = document.getElementById('player-rank-display');
const playerRankDetail = document.getElementById('player-rank-detail');
const waitingNickDisplay = document.getElementById('waiting-nick-display');

// Extrair PIN da URL caso o aluno tenha lido o QR Code
const urlParams = new URLSearchParams(window.location.search);
const pinFromUrl = urlParams.get('pin');
if (pinFromUrl) {
  inputPin.value = pinFromUrl;
  inputNickname.focus();
}

// Entrar no Jogo
btnPlayerJoin.addEventListener('click', () => {
  const pin = (inputPin.value || '').trim();
  const nickname = (inputNickname.value || '').trim();

  joinErrorMsg.classList.add('hidden');

  if (!pin || pin.length < 4) {
    showError('Digite o PIN de 6 dígitos exibido no projetor.');
    return;
  }
  if (!nickname) {
    showError('Digite o seu nome ou apelido.');
    return;
  }

  socket.emit('player_join', { pin, nickname });
});

// Erro ao entrar (sala cheia, jogo já iniciado ou PIN errado)
socket.on('join_error', (msg) => {
  showError(msg);
});

function showError(msg) {
  joinErrorMsg.textContent = msg;
  joinErrorMsg.classList.remove('hidden');
}

// Sucesso ao entrar na sala
socket.on('joined_successfully', ({ nickname, quizTitle }) => {
  waitingNickDisplay.textContent = `Olá, ${nickname}!`;
  showPlayerScreen(screenWaiting);
});

// Preparação para a pergunta (3s)
socket.on('question_intro', ({ questionNumber, totalQuestions }) => {
  document.getElementById('player-game-status').textContent = `Pergunta ${questionNumber} de ${totalQuestions}`;
  showPlayerScreen(screenGame);

  // Desabilita botões momentaneamente até o início oficial
  optionButtons.forEach(btn => {
    btn.disabled = true;
    btn.style.opacity = '0.5';
  });
});

// Pergunta ativa: Habilita os 4 botões para o clique
socket.on('question_active_player', () => {
  showPlayerScreen(screenGame);

  optionButtons.forEach(btn => {
    btn.disabled = false;
    btn.style.opacity = '1';
  });
});

// Envio da resposta ao clicar em uma das 4 cores
optionButtons.forEach(btn => {
  btn.addEventListener('click', () => {
    const optIndex = parseInt(btn.getAttribute('data-option'), 10);

    // Feedback háptico (vibração no celular se suportado)
    if (navigator.vibrate) {
      navigator.vibrate(50);
    }

    // Desativa botões para evitar clique duplo
    optionButtons.forEach(b => b.disabled = true);

    socket.emit('player_submit_answer', { optionIndex: optIndex });
    showPlayerScreen(screenSent);
  });
});

// Feedback da resposta enviada
socket.on('question_reveal_player', ({ isCorrect, points, streak, totalScore }) => {
  showPlayerScreen(screenFeedback);

  if (isCorrect) {
    feedbackCard.className = 'feedback-banner correct';
    feedbackIcon.textContent = '✓';
    feedbackTitle.textContent = 'Mandou bem!';
    feedbackPoints.textContent = `+${points} pts`;
    feedbackStreak.textContent = streak > 1 ? `Sequência de ${streak} acertos! 🔥` : '';
  } else {
    feedbackCard.className = 'feedback-banner incorrect';
    feedbackIcon.textContent = '✗';
    feedbackTitle.textContent = 'Que pena!';
    feedbackPoints.textContent = '+0 pts';
    feedbackStreak.textContent = 'Não desanime, continue tentando!';
  }

  feedbackTotal.textContent = `Pontuação total: ${totalScore} pts`;
});

// Classificação individual
socket.on('leaderboard_player', ({ rank, totalPlayers, score }) => {
  showPlayerScreen(screenRank);
  playerRankDisplay.textContent = `#${rank}`;
  playerRankDetail.textContent = `Você está em ${rank}º lugar entre ${totalPlayers} alunos (${score} pts).`;
});

// Pódio Final
socket.on('game_podium_player', ({ rank, score, totalPlayers }) => {
  showPlayerScreen(screenRank);
  playerRankDisplay.textContent = `#${rank}`;
  if (rank <= 3) {
    playerRankDetail.textContent = `PARABÉNS! Você subiu no Pódio dos Campeões com ${score} pontos! 🏅🎉`;
  } else {
    playerRankDetail.textContent = `Parabéns pela participação! Você terminou em ${rank}º de ${totalPlayers} alunos (${score} pts)!`;
  }
});

// Jogo cancelado pelo Host
socket.on('game_ended_by_host', () => {
  alert('O professor encerrou a partida.');
  window.location.reload();
});

function showPlayerScreen(screenToShow) {
  [screenJoin, screenWaiting, screenGame, screenSent, screenFeedback, screenRank].forEach(s => {
    s.classList.add('hidden');
  });
  screenToShow.classList.remove('hidden');
}
