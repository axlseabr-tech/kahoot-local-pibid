@echo off
chcp 65001 > nul
title EduQuiz Local - Preparador Microsoft Store
cls
echo ========================================================
echo   🛒 EDUQUIZ LOCAL - PREPARADOR MICROSOFT STORE
echo   PIBID Matematica • Universidade Federal de Roraima
echo ========================================================
echo.
echo [1/3] Gerando icones e ativos visuais de alta definicao...
node scripts\gerar_store_assets.js

echo.
echo [2/3] Compilando o Guia Oficial em Word (.docx)...
python scripts\compilar_guia_word.py

echo.
echo [3/3] Abrindo o portal oficial PWABuilder da Microsoft...
start https://www.pwabuilder.com
start "" "docs\Guia_Publicacao_Microsoft_Store.docx"

echo.
echo ========================================================
echo ✅ Todos os arquivos para a Microsoft Store estao prontos!
echo 📁 Pasta dos Ativos: msix_package\Assets\
echo 📄 Manifesto UWP: msix_package\AppxManifest.xml
echo 📘 Guia em Word aberto na tela!
echo ========================================================
echo.
pause
