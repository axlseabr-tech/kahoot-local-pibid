# 🎓 EduQuiz Local - PIBID Matemática UFRR

Plataforma de Quiz Interativo e Gamificado desenvolvida especialmente para escolas públicas e eventos pedagógicos do **PIBID**, funcionando **100% offline** (sem necessidade de internet).

---

## 🎯 Por que o EduQuiz Local?
Nas escolas públicas, a conexão Wi-Fi costuma ser instável ou inexistente. Esta aplicação transforma o computador do professor em um **servidor local autônomo**, permitindo que:
- O notebook gere uma rede Wi-Fi através do **Ponto de Acesso Móvel do Windows** (Hotspot).
- Os alunos se conectem com seus próprios celulares pelo Wi-Fi do notebook e leiam o **QR Code** projetado na lousa.
- O jogo aconteça com **latência zero** (< 10ms), sem anúncios, sem riscos de bloqueio e sem consumir nenhum dado de internet.

---

## 🛡️ Execução Segura no Windows (Microsoft PWA)

O **EduQuiz Local** adota o padrão oficial de **Progressive Web App (PWA)** homologado pela Microsoft:
1. Ao abrir no **Microsoft Edge**, você pode clicar no botão **"📲 Instalar App no Windows"**.
2. O aplicativo ganha ícone no Menu Iniciar, Barra de Tarefas e Desktop, abrindo em janela dedicada sem barras de navegador.
3. **Sem alertas do Smart App Control**, pois executa no ambiente seguro da engine oficial do Microsoft Edge.

---

## 🚀 Como Iniciar

1. **Ligue o Ponto de Acesso Móvel do Windows** (`Win + I` > *Rede e Internet* > *Ponto de Acesso Móvel*).
2. Dê **dois cliques** em:
   ```cmd
   iniciar_eduquiz.bat
   ```
3. O servidor ligará e o navegador abrirá automaticamente na tela do Host (`http://localhost:3000/host.html`).
4. Os alunos conectam no Wi-Fi do notebook e leem o QR Code da tela.

---

## ✏️ Criando e Editando Quizzes com Imagens
1. Na tela do Host, clique em **"✏️ Criador de Quizzes"** (ou acesse `http://localhost:3000/editor.html`).
2. Adicione enunciados, figuras geométricas ou diagramas (via arquivo, drag & drop ou **Ctrl + V**), defina as 4 opções e a resposta correta.
3. Clique em **"Salvar Quiz"**. Ele fica disponível na hora para qualquer turma jogar!

---

## 📄 Manual em PDF para Professores
O manual completo passo a passo formatado para impressão e compartilhamento está disponível em:
- `docs/Manual_EduQuiz_Local_PIBID.pdf`
- `docs/manual_impressao.html`

---

## 🛠️ Tecnologias Utilizadas
- **Node.js + Express** (Servidor HTTP local)
- **Socket.io** (Comunicação bidirecional em tempo real)
- **PWA / Microsoft Edge Manifest** (Instalação nativa no Windows)
- **Web Audio API** (Sintetizador sonoro 100% offline - sem dependência de áudios de terceiros)
- **HTML5 Canvas** (Animação de confetes no pódio)
- **QRCode** (Geração dinâmica para conexão dos celulares)
