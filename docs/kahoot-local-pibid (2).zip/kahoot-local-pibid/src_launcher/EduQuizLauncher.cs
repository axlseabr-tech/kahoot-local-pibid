using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

[assembly: AssemblyTitle("EduQuiz Local")]
[assembly: AssemblyDescription("Plataforma Gamificada de Quiz 100% Offline para Escolas")]
[assembly: AssemblyCompany("Universidade Federal de Roraima - PIBID Matematica")]
[assembly: AssemblyProduct("EduQuiz Local")]
[assembly: AssemblyCopyright("Copyright (C) 2026 Axl Oliveira Seabra")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

namespace EduQuizLocal
{
    static class Program
    {
        private static Mutex singleInstanceMutex;
        private static Process serverProcess;
        private static NotifyIcon trayIcon;
        private static ContextMenuStrip trayMenu;
        private static string appDir;

        [STAThread]
        static void Main()
        {
            // Single instance lock
            bool createdNew;
            singleInstanceMutex = new Mutex(true, "EduQuizLocal_PIBID_UFRR_Mutex", out createdNew);
            if (!createdNew)
            {
                // App already running - open host in browser and exit
                OpenUrl("http://localhost:3000/host.html");
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            appDir = AppDomain.CurrentDomain.BaseDirectory;

            // Start background server
            StartNodeServer();

            // Wait a brief moment and launch UI in Edge App Mode
            ThreadPool.QueueUserWorkItem(state =>
            {
                WaitForServerReady();
                OpenInAppMode("http://localhost:3000/host.html");
            });

            // Setup System Tray
            SetupTray();

            // Run message loop
            Application.Run();

            // Cleanup
            CleanupServer();
        }

        static void StartNodeServer()
        {
            try
            {
                string serverJs = Path.Combine(appDir, "server.js");
                if (!File.Exists(serverJs))
                {
                    // Check parent dir
                    string parentServer = Path.Combine(appDir, "..", "server.js");
                    if (File.Exists(parentServer))
                    {
                        serverJs = Path.GetFullPath(parentServer);
                        appDir = Path.GetDirectoryName(serverJs);
                    }
                }

                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = "node";
                psi.Arguments = "\"" + serverJs + "\"";
                psi.WorkingDirectory = appDir;
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                psi.WindowStyle = ProcessWindowStyle.Hidden;

                serverProcess = Process.Start(psi);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Não foi possível iniciar o motor do EduQuiz Local.\n\nDetalhes: " + ex.Message + "\n\nCertifique-se de que o Node.js está instalado no computador.",
                    "EduQuiz Local - PIBID Matemática",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
            }
        }

        static void WaitForServerReady()
        {
            int maxRetries = 20;
            for (int i = 0; i < maxRetries; i++)
            {
                try
                {
                    HttpWebRequest req = (HttpWebRequest)WebRequest.Create("http://localhost:3000/host.html");
                    req.Timeout = 1000;
                    using (HttpWebResponse res = (HttpWebResponse)req.GetResponse())
                    {
                        if (res.StatusCode == HttpStatusCode.OK) return;
                    }
                }
                catch
                {
                    Thread.Sleep(300);
                }
            }
        }

        static void OpenInAppMode(string url)
        {
            string[] edgePaths = new string[]
            {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Microsoft\\Edge\\Application\\msedge.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Microsoft\\Edge\\Application\\msedge.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Google\\Chrome\\Application\\chrome.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Google\\Chrome\\Application\\chrome.exe")
            };

            foreach (string path in edgePaths)
            {
                if (File.Exists(path))
                {
                    try
                    {
                        ProcessStartInfo psi = new ProcessStartInfo();
                        psi.FileName = path;
                        psi.Arguments = "--app=\"" + url + "\"";
                        Process.Start(psi);
                        return;
                    }
                    catch { }
                }
            }

            // Fallback to default browser
            OpenUrl(url);
        }

        static void OpenUrl(string url)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = url,
                    UseShellExecute = true
                });
            }
            catch { }
        }

        static void SetupTray()
        {
            trayMenu = new ContextMenuStrip();
            
            ToolStripMenuItem titleItem = new ToolStripMenuItem("🎓 EduQuiz Local (PIBID UFRR)");
            titleItem.Enabled = false;
            titleItem.Font = new Font(titleItem.Font, FontStyle.Bold);
            trayMenu.Items.Add(titleItem);
            trayMenu.Items.Add(new ToolStripSeparator());

            trayMenu.Items.Add("🖥️ Abrir Tela do Professor (Host)", null, (s, e) => OpenInAppMode("http://localhost:3000/host.html"));
            trayMenu.Items.Add("✏️ Abrir Criador de Quizzes", null, (s, e) => OpenInAppMode("http://localhost:3000/editor.html"));
            trayMenu.Items.Add("📱 Abrir Tela do Jogador", null, (s, e) => OpenInAppMode("http://localhost:3000/index.html"));
            trayMenu.Items.Add(new ToolStripSeparator());
            
            trayMenu.Items.Add("🌐 Abrir no Navegador Padrão", null, (s, e) => OpenUrl("http://localhost:3000/host.html"));
            trayMenu.Items.Add("🛑 Fechar EduQuiz e Encerrar Servidor", null, (s, e) => ExitApp());

            trayIcon = new NotifyIcon();
            trayIcon.Text = "EduQuiz Local - PIBID Matemática UFRR";
            trayIcon.ContextMenuStrip = trayMenu;
            trayIcon.Visible = true;

            // Load icon
            string icoPath = Path.Combine(appDir, "app.ico");
            if (File.Exists(icoPath))
            {
                try { trayIcon.Icon = new Icon(icoPath); } catch { trayIcon.Icon = SystemIcons.Application; }
            }
            else
            {
                trayIcon.Icon = SystemIcons.Application;
            }

            trayIcon.DoubleClick += (s, e) => OpenInAppMode("http://localhost:3000/host.html");

            trayIcon.ShowBalloonTip(
                3000,
                "EduQuiz Local Ativo!",
                "Servidor local rodando na porta 3000. Dê dois cliques para abrir ou acesse pelo menu da bandeja.",
                ToolTipIcon.Info
            );
        }

        static void ExitApp()
        {
            if (trayIcon != null)
            {
                trayIcon.Visible = false;
                trayIcon.Dispose();
            }
            CleanupServer();
            Application.Exit();
        }

        static void CleanupServer()
        {
            try
            {
                if (serverProcess != null && !serverProcess.HasExited)
                {
                    serverProcess.Kill();
                    serverProcess.Dispose();
                }
            }
            catch { }
        }
    }
}
