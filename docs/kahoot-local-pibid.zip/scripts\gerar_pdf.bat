@echo off
chcp 65001 >nul
title Gerador de PDF do Manual - Kahoot Local

echo Gerando Manual_Kahoot_Local_PIBID.pdf a partir do manual_impressao.html...

set EDGE="C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
if not exist %EDGE% set EDGE="C:\Program Files\Microsoft\Edge\Application\msedge.exe"

%EDGE% --headless --disable-gpu --no-sandbox --print-to-pdf="%~dp0..\docs\Manual_Kahoot_Local_PIBID.pdf" "%~dp0..\docs\manual_impressao.html"

if exist "%~dp0..\docs\Manual_Kahoot_Local_PIBID.pdf" (
    echo.
    echo ======================================================
    echo ✓ PDF gerado com sucesso em: docs\Manual_Kahoot_Local_PIBID.pdf
    echo ======================================================
) else (
    echo [ERRO] Nao foi possivel gerar o PDF automaticamente.
)
pause
