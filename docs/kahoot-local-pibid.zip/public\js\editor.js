const questionsList = document.getElementById('questions-list');
const btnAddQuestion = document.getElementById('btn-add-question');
const btnSaveQuiz = document.getElementById('btn-save-quiz');
const quizTitle = document.getElementById('quiz-title');
const quizDesc = document.getElementById('quiz-desc');

let questions = [];

// Adicionar Pergunta Padrão
function addQuestionCard(data = null) {
  const qIndex = questions.length;
  const qData = data || {
    question: '',
    time: 20,
    points: 1000,
    options: ['', '', '', ''],
    correctIndex: 0,
    explanation: ''
  };

  questions.push(qData);
  renderQuestions();
}

function renderQuestions() {
  questionsList.innerHTML = '';

  questions.forEach((q, idx) => {
    const card = document.createElement('div');
    card.className = 'question-card';
    card.innerHTML = `
      <div class="card-header">
        <h3 style="font-size: 20px;">Pergunta #${idx + 1}</h3>
        <div style="display: flex; gap: 12px; align-items: center;">
          <label style="font-size: 14px; font-weight: bold;">Tempo: 
            <select class="q-time-select" data-idx="${idx}" style="padding: 4px 8px; border-radius: 6px; font-weight: bold;">
              <option value="10" ${q.time === 10 ? 'selected' : ''}>10 seg</option>
              <option value="15" ${q.time === 15 ? 'selected' : ''}>15 seg</option>
              <option value="20" ${q.time === 20 ? 'selected' : ''}>20 seg</option>
              <option value="30" ${q.time === 30 ? 'selected' : ''}>30 seg</option>
              <option value="60" ${q.time === 60 ? 'selected' : ''}>60 seg</option>
            </select>
          </label>
          ${questions.length > 1 ? `<button class="btn-remove" onclick="removeQuestion(${idx})">Excluir</button>` : ''}
        </div>
      </div>

      <div class="input-group">
        <label>Texto da Pergunta:</label>
        <input type="text" class="q-text-input" data-idx="${idx}" value="${escapeHtml(q.question)}" placeholder="Digite o enunciado da questão">
      </div>

      <div style="display: flex; flex-direction: column; gap: 10px;">
        <label style="font-size: 14px; font-weight: bold; color: #444;">Opções de Resposta (Marque o círculo da alternativa correta):</label>
        
        <div class="option-input-row" style="background: #ffebee; padding: 8px 12px; border-radius: 10px;">
          <input type="radio" name="correct-${idx}" class="option-radio" ${q.correctIndex === 0 ? 'checked' : ''} onchange="setCorrect(${idx}, 0)">
          <span style="font-weight: 900; color: #e21b3c; width: 30px;">▲</span>
          <input type="text" style="flex: 1; padding: 8px 12px; border-radius: 8px; border: 1px solid #ccc;" value="${escapeHtml(q.options[0])}" oninput="setOptionText(${idx}, 0, this.value)" placeholder="Alternativa A (Vermelho)">
        </div>

        <div class="option-input-row" style="background: #e3f2fd; padding: 8px 12px; border-radius: 10px;">
          <input type="radio" name="correct-${idx}" class="option-radio" ${q.correctIndex === 1 ? 'checked' : ''} onchange="setCorrect(${idx}, 1)">
          <span style="font-weight: 900; color: #1368ce; width: 30px;">◆</span>
          <input type="text" style="flex: 1; padding: 8px 12px; border-radius: 8px; border: 1px solid #ccc;" value="${escapeHtml(q.options[1])}" oninput="setOptionText(${idx}, 1, this.value)" placeholder="Alternativa B (Azul)">
        </div>

        <div class="option-input-row" style="background: #fffde7; padding: 8px 12px; border-radius: 10px;">
          <input type="radio" name="correct-${idx}" class="option-radio" ${q.correctIndex === 2 ? 'checked' : ''} onchange="setCorrect(${idx}, 2)">
          <span style="font-weight: 900; color: #d89e00; width: 30px;">●</span>
          <input type="text" style="flex: 1; padding: 8px 12px; border-radius: 8px; border: 1px solid #ccc;" value="${escapeHtml(q.options[2])}" oninput="setOptionText(${idx}, 2, this.value)" placeholder="Alternativa C (Amarelo)">
        </div>

        <div class="option-input-row" style="background: #e8f5e9; padding: 8px 12px; border-radius: 10px;">
          <input type="radio" name="correct-${idx}" class="option-radio" ${q.correctIndex === 3 ? 'checked' : ''} onchange="setCorrect(${idx}, 3)">
          <span style="font-weight: 900; color: #26890c; width: 30px;">■</span>
          <input type="text" style="flex: 1; padding: 8px 12px; border-radius: 8px; border: 1px solid #ccc;" value="${escapeHtml(q.options[3])}" oninput="setOptionText(${idx}, 3, this.value)" placeholder="Alternativa D (Verde)">
        </div>
      </div>

      <div class="input-group">
        <label>Explicação / Comentário (Opcional - exibido após a resposta):</label>
        <input type="text" class="q-exp-input" data-idx="${idx}" value="${escapeHtml(q.explanation || '')}" placeholder="Ex: O Teorema de Pitágoras diz que a² = b² + c²">
      </div>
    `;

    // Listeners
    const textInput = card.querySelector('.q-text-input');
    textInput.addEventListener('input', (e) => {
      questions[idx].question = e.target.value;
    });

    const timeSelect = card.querySelector('.q-time-select');
    timeSelect.addEventListener('change', (e) => {
      questions[idx].time = parseInt(e.target.value, 10);
    });

    const expInput = card.querySelector('.q-exp-input');
    expInput.addEventListener('input', (e) => {
      questions[idx].explanation = e.target.value;
    });

    questionsList.appendChild(card);
  });
}

function setCorrect(qIdx, optIdx) {
  questions[qIdx].correctIndex = optIdx;
}

function setOptionText(qIdx, optIdx, val) {
  questions[qIdx].options[optIdx] = val;
}

function removeQuestion(idx) {
  if (confirm(`Deseja remover a pergunta #${idx + 1}?`)) {
    questions.splice(idx, 1);
    renderQuestions();
  }
}

function escapeHtml(text) {
  if (!text) return '';
  return text.replace(/"/g, '&quot;');
}

btnAddQuestion.addEventListener('click', () => {
  addQuestionCard();
});

// Salvar Quiz
btnSaveQuiz.addEventListener('click', async () => {
  const title = (quizTitle.value || '').trim();
  const desc = (quizDesc.value || '').trim();

  if (!title) {
    alert('Por favor, informe um título para o quiz.');
    quizTitle.focus();
    return;
  }

  if (questions.length === 0) {
    alert('Adicione pelo menos 1 pergunta.');
    return;
  }

  // Validação das opções
  for (let i = 0; i < questions.length; i++) {
    const q = questions[i];
    if (!q.question.trim()) {
      alert(`A Pergunta #${i + 1} está sem enunciado.`);
      return;
    }
    for (let o = 0; o < 4; o++) {
      if (!q.options[o].trim()) {
        alert(`A Pergunta #${i + 1} está com a Alternativa ${['A','B','C','D'][o]} vazia.`);
        return;
      }
    }
  }

  const payload = {
    title,
    description: desc,
    questions: questions.map((q, idx) => ({
      id: idx + 1,
      question: q.question.trim(),
      time: q.time || 20,
      points: 1000,
      options: q.options.map(o => o.trim()),
      correctIndex: q.correctIndex,
      explanation: q.explanation.trim()
    }))
  };

  try {
    const res = await fetch('/api/quizzes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const result = await res.json();
    if (result.success) {
      alert('🎉 Quiz salvo com sucesso! Já está disponível para ser jogado na tela do Host.');
      window.location.href = '/host.html';
    } else {
      alert('Erro ao salvar quiz: ' + (result.error || 'Desconhecido'));
    }
  } catch (err) {
    alert('Erro de conexão ao salvar quiz.');
  }
});

// Começar com 1 pergunta vazia
addQuestionCard();
