// Gerador de Efeitos Sonoros 100% Offline via Web Audio API (Zero downloads de áudio)
class SoundEffects {
  constructor() {
    this.ctx = null;
    this.lobbyInterval = null;
    this.isMuted = false;
  }

  init() {
    if (!this.ctx) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AudioContext();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  // Tocar tom simples com frequência, tipo de onda e envelope ADSR
  playTone(freq, type = 'sine', duration = 0.15, gainVal = 0.2, delay = 0) {
    if (this.isMuted) return;
    this.init();
    
    const startTime = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, startTime);

    gain.gain.setValueAtTime(0.0001, startTime);
    gain.gain.exponentialRampToValueAtTime(gainVal, startTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(startTime);
    osc.stop(startTime + duration);
  }

  // Música do Lobby estilo Kahoot (Sintetizada em tempo real)
  startLobbyMusic() {
    if (this.isMuted) return;
    this.init();
    this.stopLobbyMusic();

    const notes = [
      261.63, 329.63, 392.00, 523.25, // C4, E4, G4, C5
      293.66, 349.23, 440.00, 587.33, // D4, F4, A4, D5
      329.63, 392.00, 493.88, 659.25, // E4, G4, B4, E5
      392.00, 523.25, 659.25, 783.99  // G4, C5, E5, G5
    ];
    let step = 0;

    this.lobbyInterval = setInterval(() => {
      if (this.isMuted) return;
      const f = notes[step % notes.length];
      this.playTone(f, 'triangle', 0.22, 0.08);

      // Linha de baixo a cada 4 batidas
      if (step % 4 === 0) {
        this.playTone(130.81, 'sine', 0.4, 0.15); // Baixo C3
      }
      step++;
    }, 280);
  }

  stopLobbyMusic() {
    if (this.lobbyInterval) {
      clearInterval(this.lobbyInterval);
      this.lobbyInterval = null;
    }
  }

  // Som de tick da contagem regressiva
  playTick() {
    this.playTone(800, 'sine', 0.06, 0.15);
  }

  playUrgentTick() {
    this.playTone(1200, 'square', 0.08, 0.2);
  }

  // Som de Acerto (Chime ascendente alegre)
  playCorrect() {
    this.stopLobbyMusic();
    const chords = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
    chords.forEach((freq, idx) => {
      this.playTone(freq, 'triangle', 0.35, 0.18, idx * 0.08);
    });
  }

  // Som de Erro (Buzzer descendente)
  playIncorrect() {
    this.stopLobbyMusic();
    this.playTone(280, 'sawtooth', 0.25, 0.18, 0);
    this.playTone(200, 'sawtooth', 0.35, 0.2, 0.18);
  }

  // Fanfarra de Vitória para o Pódio Olímpico
  playPodiumFanfare() {
    this.stopLobbyMusic();
    this.init();
    const fanfareNotes = [
      { f: 523.25, d: 0.15, t: 0 },
      { f: 523.25, d: 0.15, t: 0.15 },
      { f: 523.25, d: 0.15, t: 0.30 },
      { f: 659.25, d: 0.50, t: 0.45 },
      { f: 587.33, d: 0.25, t: 0.95 },
      { f: 659.25, d: 0.25, t: 1.20 },
      { f: 783.99, d: 0.80, t: 1.45 },
      { f: 1046.50, d: 1.2, t: 2.25 }
    ];

    fanfareNotes.forEach(n => {
      this.playTone(n.f, 'triangle', n.d, 0.25, n.t);
      this.playTone(n.f / 2, 'sine', n.d, 0.2, n.t); // Harmônico encorpado
    });
  }
}

window.soundEffects = new SoundEffects();
