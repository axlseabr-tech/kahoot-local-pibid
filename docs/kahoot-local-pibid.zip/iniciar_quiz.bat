@echo off
title Kahoot Local PIBID - Servidor

echo ======================================================
echo    KAHOOT LOCAL PIBID - DIA DA MATEMATICA
echo ======================================================
echo.
echo Iniciando o servidor do quiz...
echo Abra o navegador na tela do projetor: http://localhost:3000/host.html
echo.
start http://localhost:3000/host.html
node server.js
pause
