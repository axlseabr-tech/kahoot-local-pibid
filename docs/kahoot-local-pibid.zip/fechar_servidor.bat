@echo off
title Fechar Servidor - Kahoot Local

echo ======================================================
echo    ENCERRANDO SERVIDOR DO KAHOOT LOCAL (PORTA 3000)
echo ======================================================
echo.

for /f "tokens=5" %%a in ('netstat -aon ^| findstr :3000 ^| findstr LISTENING') do (
    echo Encerrando processo PID: %%a...
    taskkill /F /PID %%a >nul 2>&1
)

echo.
echo ======================================================
echo    ??? A PORTA 3000 FOI FECHADA COM SUCESSO!
echo ======================================================
echo.
pause
