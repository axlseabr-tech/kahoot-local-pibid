@echo off
title Instalador de Dependencias - Kahoot Local

echo ======================================================
echo    INSTALANDO DEPENDENCIAS DO KAHOOT LOCAL
echo ======================================================
echo.
call npm install
echo.
echo ======================================================
echo    CONCLUIDO COM SUCESSO!
echo    Agora basta abrir o arquivo iniciar_quiz.bat
echo ======================================================
pause
