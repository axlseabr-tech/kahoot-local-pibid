# 📐 Kahoot Local PIBID - Dia da Matemática

Plataforma de Quiz interativo estilo **Kahoot!** feita especificamente para escolas públicas e eventos pedagógicos do **PIBID**, funcionando **100% offline** (sem necessidade de internet).

---

## 🎯 Por que o Kahoot Local?
Nas escolas, a conexão Wi-Fi costuma ser instável ou inexistente. Esta aplicação transforma o computador do professor em um **servidor local**, permitindo que:
- O notebook gere uma rede Wi-Fi através do **Ponto de Acesso Móvel do Windows** (Hotspot).
- Os alunos se conectem com seus próprios celulares pelo Wi-Fi do notebook e leiam o **QR Code** projetado na tela.
- O jogo aconteça com **latência zero** (< 10ms) e sem consumir nenhum dado de internet.

---

## 🚀 Como Iniciar com 1 Clique (Windows)

1. **Ligue o Ponto de Acesso Móvel do Windows** (Configurações > Rede e Internet > Ponto de Acesso Móvel).
2. Dê **dois cliques** em:
   ```cmd
   iniciar_quiz.bat
   ```
3. O servidor ligará e o navegador abrirá automaticamente na tela do Host (`http://localhost:3000/host.html`).
4. Os alunos conectam no Wi-Fi do notebook e leem o QR Code da tela (ou acessam o link indicado no topo).

---

## ✏️ Criando Novos Quizzes
1. Na tela do Host, clique em **"✏️ Editar Quizzes"** (ou acesse `http://localhost:3000/editor.html`).
2. Digite o título, adicione perguntas com 4 opções, defina a resposta correta e o tempo (10s a 60s).
3. Clique em **"Salvar Quiz"**. Ele fica disponível na hora para qualquer turma jogar!

---

## 📄 Manual em PDF para Professores e Colegas
O manual completo passo a passo formatado para impressão e compartilhamento já está gerado em:
- [Manual_Kahoot_Local_PIBID.pdf](file:///C:/Users/Axl%20O%20S/.gemini/antigravity-ide/scratch/kahoot-local-pibid/docs/Manual_Kahoot_Local_PIBID.pdf)
- [manual_impressao.html](file:///C:/Users/Axl%20O%20S/.gemini/antigravity-ide/scratch/kahoot-local-pibid/docs/manual_impressao.html)

---

## 🛠️ Tecnologias Utilizadas
- **Node.js + Express** (Servidor HTTP)
- **Socket.io** (Comunicação bidirecional em tempo real)
- **Web Audio API** (Sintetizador sonoro 100% offline - sem MP3s externos)
- **HTML5 Canvas** (Animação de confetes no pódio)
- **QRCode** (Geração dinâmica para conexão dos celulares)
